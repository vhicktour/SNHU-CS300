Open the Terminal in VSCode.
Navigate to your project directory using the cd command.
Compile your C++ files with g++, including all the necessary source files in the command.
Run the compiled executable with ./ProgramExecutable.
Interact with your program as per the menu prompts.
Use the correct file name when prompted to ensure the program loads the data successfully.
To exit the program, choose the option provided in the menu.
Cheers